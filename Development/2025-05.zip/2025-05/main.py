import uuid # randomization
import random

class Product:

    CALORIES_TO_KILOJOULES=4.184

    def __init__(self, name, calories, price_per_kg):
        self.name=name
        self.calories=calories
        self.price_per_kg=price_per_kg

    def get_price(self, weight_kgs):
        return self.price_per_kg*weight_kgs

    def get_kilojoules(self):
        return self.calories * self.CALORIES_TO_KILOJOULES
    @staticmethod
    def generate_unique_id():
        return f"Product-{random.uniform(0,500)}"

banana=Product("banana", 105, 1.0)
tomato=Product("tomato", 22, 2.1)
potato=Product("potato", 162, 0.9)

print(f"KJ of {banana.name} is {banana.get_kilojoules()}")
print(f"KJ of {tomato.name} is {tomato.get_kilojoules()}")

print(Product.generate_unique_id())