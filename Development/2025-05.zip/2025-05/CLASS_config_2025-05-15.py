import os, time

class Config():
#    def __init__(self, font, brightness, white_balance, display_rotation, autoscroll_duration, timelapse_duration, timestamp_photo):
    def __init__(self):
        self.h=0
        pass

    def load():
        config_path=r"C:/Users/ckingsbury/OneDrive - City of Port Orange/Desktop/ePaper-Pi-Cam/config.txt"
        config={}
        if os.path.exists(config_path):
            with open(config_path, 'r') as file:
                for line in file:
                    if "=" in line:
                        key, value=line.strip().split("=", 1)
                        config[key]=value
            print("Loaded config.")
        else:
            print("No config file.")
        return config

    def save():
        config_path=r"C:/Users/ckingsbury/OneDrive - City of Port Orange/Desktop/ePaper-Pi-Cam/config.txt"
        print("Saving options....")
        # Save updated config
        with open(config_path, 'w') as file:
            for key, value in config.items():
                file.write(f"{key}={value}\n")
            print("Saved!")
            time.sleep(.5)
        print("Options saved")
        return

config=Config.load()
config["font"]="dfergth"
Config.save()
config=Config.load()
print(config["font"])