# from gpiozero import LED, Button
import time, datetime, os, logging, sys
#from picamzero import Camera
#from waveshare_epd import epd2in7_V2 # -- the 2.7inch GPIO HAT
#from PIL import Image, ImageDraw, ImageFont
# from config import Config
import keyboard

class ButtonPress:
    def __init__(self):
        pass
    def wait_for_multiple_keys():
        keys=['q', 'w', 'e', 'r']
        p=keyboard.read_key()
        time.sleep(0.2)
        if p in keys:
            if p=="q":
                menu_type="Main Menu"
            elif p=="w":
                menu_type="Options"
            elif p=="e":
                menu_type="Camera"
            elif p=="r":
                menu_type="Autoscroll"

            if menu_type!=None:
                return menu_type

class GetSelection():
    def __init__(self):
        pass
    def select(s):
        if s!=None:
            print(f"Selected: {s}")
            return s

class BuildMenu():
    def __init__(self):
        pass
    def menu(menu_type):
        if menu_type!=None:
            print(f"Building menu: {menu_type}")

try:
    while True:
        p=ButtonPress.wait_for_multiple_keys()
        selection=GetSelection.select(p)
        BuildMenu.menu(selection)
#        keyboard.wait(keys) # Waits for key to be pressed

except Exception as e:
    print("User Exited: "+str(e))


