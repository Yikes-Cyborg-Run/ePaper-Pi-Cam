import keyboard, time
class BuildMenu():
    def __init__(self):
        pass
    def menu(h, selected):
        use_menu="Main Menu"
        if selected=="Main Menu":
            use_menu=["Camera", "Camera Options", "Manual List", "Autoscroll", "Time-Lapse", "Delete"]
            go_back_to="Main Menu"
        if selected=="Camera Options":
            use_menu=["Font", "opt1", "opt 2", "Main Menu"]
            go_back_to="Main Menu"

        limit=len(use_menu)-1
        k=keyboard.read_key()
        time.sleep(0.2)

        if k:
            if k=="up":
                h+=1 
                if h>limit:h=0
            if k=="down":
                h-=1
                if h<0:h=limit
            if k=="enter":
                selected=use_menu[h]
            if k=="esc":
                selected=go_back_to
        print(selected.upper())
        highlighted=use_menu[h]
        for item in use_menu:
            if item==highlighted:
                item=">"+item
            print (f"item: {item}")
        return [h, selected]