import keyboard, time

class GetMenu:
    def __init__(self):
        pass
    def menu():
        keys=['q', 'w', 'e', 'r']
        p=keyboard.read_key()
        time.sleep(0.2)
        menu_type=None
        print(p)
        if p:
            print(f"pressed: {p}")
            if p in keys:
                if p=="q":
                    menu_type="Main Menu"
                elif p=="w":
                    menu_type="Options"
                elif p=="e":
                    menu_type="Camera"
                elif p=="r":
                    menu_type="Autoscroll"
                if menu_type!=None:
                    return menu_type
                else: pass
        else: pass

class NavigateMenu:
    def __init__(self):
        pass
    def nav(h):
        keys=['up', 'down']
        p=keyboard.read_key()
        time.sleep(0.2)
        if p in keys:
            if p=="up":h+=1
            elif p=="down":h-=1
            return h
        else:
            pass


class BuildMenu():
    def __init__(self):
        pass
    def menu(h):
        use_menu=None
        main_menu=["Camera", "Camera Options", "Manual List", "Autoscroll", "Time-Lapse", "Delete"]
        use_menu=main_menu
        k=keyboard.read_key()
        time.sleep(0.2)

        if k:
            print(f"pressed: {k}")
            if k=="up":
                h+=1 
                if h>len(use_menu)-1:h=0
            if k=="down":
                h-=1
                if h<0:h=len(use_menu)
            if k=="enter":
                selected=use_menu[h]
                print(f"selected: {selected}")
                return [h,selected]

        if use_menu!=None:
            highlighted=use_menu[h]
            print(f"use_menu: {use_menu}")
            for item in use_menu:
                if item==highlighted:
                    item=">"+item
                print (f"item: {item}")
        return [h,selected]