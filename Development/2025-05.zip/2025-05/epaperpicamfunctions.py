import RPi.GPIO as GPIO
from gpiozero import LED, Button
import time, datetime, os, logging
from datetime import datetime, date
from picamzero import Camera
from waveshare_epd import epd2in7_V2 # -- is for the GPIO HAT
#from waveshare_epd import epd4in2_V2 # -- is for the 4inch display
from PIL import Image,ImageDraw,ImageFont

def log(msg, err_type):
	global logger
	err=["ERROR", "INFO", "DEBUG", "CRITICAL", "WARNING"]
	print(err[err_type]+" : "+msg)
	if(err_type==0):logger.error(msg)
	elif(err_type==1):logger.info(msg)
	elif(err_type==2):logger.debug(msg)
	elif(err_type==3):logger.critical(msg)
	elif(err_type==4):logger.warning(msg)

def save_config(config):
    with open("/home/pi/ePaper-Pi-Cam/config.txt", 'w') as file:
        for key, value in config.items():
            file.write(f"{key}={value}\n")

def load_config():
	config={}
	if os.path.exists("/home/pi/ePaper-Pi-Cam/config.txt"):
		with open("/home/pi/ePaper-Pi-Cam/config.txt", 'r') as file:
			for line in file:
				if "=" in line:
					key, value=line.strip().split("=", 1)
					config[key]=value
	else:
		log("No config file.", 0)
	return config

def menu(title, highlight, menu_array):
	global config_font, photo_array
	show=str(highlight)
	highlight=menu_array[highlight]
	log("Building menu, selected - "+show+" - "+highlight, 1)
	image=Image.new("1", (epd.height, epd.width), 255) 	# Create a new image with a white background
#	image=image.transpose(Image.ROTATE_180)
	draw=ImageDraw.Draw(image)
#	draw=draw.transpose(Image.ROTATE_180)
	y=40 # will increment to place menu items vertically
	# Load font and loop thorugh menu array
	font=ImageFont.truetype(str(config_font), 18)
	draw.text((20,10),title,font=font,fill=0)
	font=ImageFont.truetype(str(config_font), 16)
	for item in menu_array:
		# log(item,1)
		if item==highlight:
			show="- "+item
			if item=="Camera":
				show="- Camera - push photo button..."
			elif item=="List":
				show="- List - "+str(len(photo_array))+" photos..."
		else:
			show=item
		if item!="Menu":
			draw.text((20,y),show+"\n",font=font,fill=0)
			y+=25 # add so that the y position increments as menu items are added
	epd.display(epd.getbuffer(image))
	log("menu_made=True", 1)
	return True

def display_photo(photo_array, key):
	log("Loading file...", 1)
	filename=photo_array[key]
	log("display file: "+filename,1)
	image=Image.open(filename)
	image=image.resize((epd.height, epd.width)) # ADDED THIS to check if scroll images woud work
	draw=ImageDraw.Draw(image)
	font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
	draw.text((5, 280), filename, font=font, fill=1)
	epd.display(epd.getbuffer(image))

def purge_photo_dir(image_folder):
	log("Attempting to purge all photos...")
	for filename in os.listdir(image_folder):
		file_path=os.path.join(image_folder, filename)
		try:
			if os.path.isfile(file_path) or os.path.islink(file_path):
				os.unlink(file_path)
			elif os.path.isdir(file_path):
				shutilrmtree(file_path)
		except Exception as e:
			log("Failed to delete", 0)

# Control the LEDs, 1 = turn it on
def LED(green,yellow,red):
	if green==1: GPIO.output(LED_G, GPIO.HIGH)
	else: GPIO.output(LED_G, GPIO.LOW)
	if yellow==1: GPIO.output(LED_Y, GPIO.HIGH)
	else: GPIO.output(LED_Y, GPIO.LOW)
	if red==1: GPIO.output(LED_R, GPIO.HIGH)
	else: GPIO.output(LED_R, GPIO.LOW)

def draw_text(x,y,size,txt):
	font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size)
	draw.text((20, 50), "Ready to take photo", font=font, fill=0)
	draw.text((20, 100), "Image Dir: "+image_folder, font=font, fill=0)
	epd.display(epd.getbuffer(image))
	return

def master_menu(menu_made, selection, highlight, array_to_use, config, config_key, return_selection):
	global up_state, down_state, photo_state
	if menu_made==False:
		menu_made=menu(selection, highlight, array_to_use)
	if up_state==False:
		highlight+=1
		menu_made=menu(selection, highlight, array_to_use)
		if highlight>len(array_to_use):
			highlight=0
	elif down_state==False:
		highlight-=1
		menu_made=menu(selection, highlight, array_to_use)
		if highlight<0:
			highlight=len(array_to_use)
	elif photo_state==False:
		new_value=array_to_use[highlight]
		config[config_key]=new_value
		save_config(config)
		highlight=0
		menu_made=False
		selection=return_selection
		result=[{"selection":selection}, {"highlight":highlight}, {"menu_made":menu_made}, {"config_key_to_save":config_key}, {"config_value_to_save": new_value}]
		return result