from camera_classes import BuildMenu, GetSelection, Config, Warn, Action
import os

def main():
	data=[0, "Main Menu"]
	photo_increment=0
#	font_directory="/home/pi/ePaper-Pi-Cam/Fonts"
	font_directory=r"C:/Users/ckingsbury/OneDrive - City of Port Orange/Desktop/ePaper-Pi-Cam/Fonts"
	photo_list=[]
	image_folder="/home/pi/ePaper-Pi-Cam/photos/"
	"""
	# Menu & Options lists
	menu_list={
			"Main Menu":["Camera", "Camera Options", "Time-lapse Camera", "Autoscroll", "Manual Scroll", "Delete All Photos"],
			"Camera Options":["Font Selection", "Font Size", "Display Rotation", "Autoscroll Duration", "Time-Lapse Duration", "White Balance", "Shut Down", "Delete Photos"],
			"White Balance":["auto", "tungsten", "fluorescent", "indoor", "daylight", "cloudy"],
			"Font Size":["-4", "-2", "0", "+2", "+4"],
			"Autoscroll Duration":[10, 30, 60, 120, 300, 600],
			"Time-lapse Duration":[1, 30, 60, 300, 600, 1800, 3600],
			"Display Rotation":[90, 180, 270],
			"Timestamp Photo":["True", "False"],
			"Font Selection":[f for f in os.listdir(font_directory) if os.path.isfile(os.path.join(font_directory, f))]
			}
	"""
	action_list=["Take Photo", "Time-lapse Camera", "Autoscroll", "Manual Scroll", "Delete All Photos"]
	ignore_list=["Take Photo", "Time-lapse Camera", "Autoscroll", "Manual Scroll", "Delete All Photos", "Delete All Photos", "Delete Single", "Camera", "Time-Lapse Camera"]
	warn_list=["Delete All Photos", "Delete Single", "Camera", "Time-Lapse Camera"]

	config=Config.load()

	# Build main menu before loop begins
	BuildMenu.menu(data[0], data[1], menu_list)

	while True:
		h=data[0]
		selection=data[1]
#		print(f"{selection} - h: {h} ")
		if selection in warn_list:
			print("warn")
			data=Warn.warn(selection)
		elif selection in action_list:
			print("its an action")
			if selection =="Take Photo":
				Action.take_photo(config, photo_list, image_folder)
				data=[0, selection]
			if selection =="Manual Scroll":
				photo_increment=Action.manual_scroll(photo_increment)
		else:
			BuildMenu.menu(h, selection, menu_list)
			data=GetSelection.select(h, selection, menu_list, ignore_list)

if __name__ == "__main__":
    main()