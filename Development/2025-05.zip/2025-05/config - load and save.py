import os

def save_settings(filename, settings):
    with open(filename, 'w') as file:
        for key, value in settings.items():
            file.write(f"{key}={value}\n")

def load_settings(filename):
    settings = {}
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            for line in file:
                if "=" in line:
                    key, value = line.strip().split("=", 1)
                    settings[key] = value
    return settings

if __name__ == "__main__":
    settings_file = "settings.txt"
    default_settings = {"name": "CJK", "level": "2"}
    
    # Load existing settings or use defaults
    loaded_settings = load_settings(settings_file)
    settings = default_settings.copy()
    settings.update(loaded_settings)
    
    # Display current settings
    print("Current settings:")
    for key, value in settings.items():
        print(f"{key}: {value}")
    
    # Modify settings
    settings["level"] = "2"
    
    # Save updated settings
    save_settings(settings_file, settings)
    print("Settings saved.")

    #Reload and display
    loaded_settings = load_settings(settings_file)
    print("Reloaded settings:")
    for key, value in loaded_settings.items():
        print(f"{key}: {value}")