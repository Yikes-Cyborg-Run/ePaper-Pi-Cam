# This code runs only in python 3.10 or above versions
def num_to_str(argument):
    try:
        match argument:
            case 0: return "Option 0"
            case 1: return "Option 1"
            case 2: return "Option 2"
            case 3: return "Option 3"
            case 4: return "Option 4"
#            case default: return "Option 1"
    except:
        return("No match")

print(num_to_str(6))